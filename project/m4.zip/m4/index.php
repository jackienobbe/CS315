<!DOCTYPE html>
  <head>

    <title>aqua-archive // home</title>
    <link type="text/css" rel="stylesheet" href="css/aqua.css" />
    <meta charset="UTF-8">

  </head>

  <!-- <body>
    <div id="wrapper"> -->
      <?php include('includes/header.php'); ?>
      <div id="content">
        <h2>Recent Bands</h2>
        <ul>
          <li>American Basswood</li>
          <li>Counting Black Sheep</li>
          <li><a href="viewBandGigantic.php">Gigantic</a></li>
          <li>Josh Brumfield</li>
          <li>Radio Free Kirksville</li>
        </ul>
        <h2>Recent Shows</h2>
        <ul>
          <li><a href="viewShowGigantic.php">The GIGANTIC Aquadome Show</a></li>
          <li>Aquadome HOUSE SHOW</li>
          <li>Finals Fever Reliever 2k16!</li>
          <li>Chew Toy // Lesbian Poetry // Seen From Space </li>
          <li>Dome of the Dead!</li>
        </ul>
      </div>
    </div>

  </body>

</html>
